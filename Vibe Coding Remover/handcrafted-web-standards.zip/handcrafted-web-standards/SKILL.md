---
name: handcrafted-web-standards
description: House rules for building, redesigning, reviewing or launching any website, landing page, portfolio, web app UI or site copy, and for research projects. Use it whenever web design, front-end code, marketing copy or a site launch is involved, even if the user does not name this skill. Enforces: no purple gradients, pill buttons, emoji icons, em dashes, fake reviews, metrics or counters, AI-generated photos or copy, vague hero text, cursor effects or heavy scroll animation; a launch gate (custom domain, favicon, no Made-with badge, privacy and terms pages); an empathy map of the end user first; and a full references list for research.
---

# Handcrafted Web Standards

The owner of this skill does not want anything that looks "vibe-coded": the generic, AI-template look that visitors now recognise instantly and distrust. Every rule below exists to protect credibility. A visitor who spots one fake review or one stock AI hero stops believing everything else on the page, so these are not style preferences to trade off. Treat them as hard requirements.

The same care applies to research work: nothing is claimed without a source, and every source is listed.

## 1. Start with the end user (empathy map)

Before designing or writing anything, understand who will use the site and what state of mind they arrive in. A page built for "everyone" ends up with vague hero text and generic copy, which is exactly the vibe-coded look this skill exists to avoid.

Build a short empathy map and show it to the user before building:

- **Who**: the specific person (role, context, how technical they are, language, location).
- **Says / Thinks**: what they would type into a search bar; what they worry about privately.
- **Does**: how they arrive (search, ad, referral), on what device and connection, how much time they have.
- **Feels**: the emotion on arrival (rushed, sceptical, anxious, curious).
- **Pains**: what stops them acting today (cost, risk, confusion, trust).
- **Gains**: what "done" looks like for them.
- **The one action** the page should lead them to.

If the user has not given enough to fill this in, ask (two or three pointed questions, not a questionnaire). If no one is available to ask, write down the assumptions you made at the top of your handoff so they can be corrected.

Then trace decisions back to the map: the headline answers their search, the first section removes their biggest pain, accessibility and page weight match their device and connection. When you hand off, include a short "Why it's built this way" note linking key choices to the map.

## 2. Visual rules

| Never | Do instead |
|---|---|
| Purple, violet, indigo or purple-to-pink gradients (in CSS, Tailwind `from-purple-*`, SVG or images) | A palette drawn from the brand or subject: mostly solid colours, one accent. If a gradient is truly needed, a subtle same-hue tonal shift that is not purple. |
| Pill-shaped buttons (`rounded-full`, `border-radius: 9999px`, radius at or above half the height) | Squared or modestly rounded buttons (roughly 0 to 8px radius). Keep radius consistent across the site. |
| Emoji used as icons or decoration (🚀 ✨ ✅ ⚡ etc.) | A consistent SVG icon set (for example Lucide, Phosphor, Heroicons), or no icon. Text labels beat icons when unsure. |
| AI-generated ("slop") photos or illustrations | The owner's real photos (product, team, place, work). If none exist, a type-led layout with no photography, and a note in the handoff saying which real photos would help. Never generate images to fill space. |
| Cursor animations: custom cursors, trails, blobs, magnetic buttons, `cursor: none` | The system cursor. |
| Over-the-top scroll animation: parallax, scroll-jacking, smooth-scroll libraries, every block fading or sliding in, AOS or GSAP ScrollTrigger reveals | Static content. Motion only for feedback (hover, focus, a menu opening), 100 to 250ms, and always wrapped so `prefers-reduced-motion: reduce` turns it off. |

Also avoid the other tells of the template look: centred everything, three identical feature cards with icons, glassmorphism panels, glowing blobs, "bento" grids used for no reason. Make layout choices because the content needs them.

## 3. Content rules

**No fake social proof, ever.** No invented reviews, testimonials, star ratings, customer logos, "trusted by" lines, user counts, uptime numbers, percentages or animated customer counters. Use only numbers and quotes the owner has supplied and can back up, with the person's real name and permission. If you don't have them, leave that section out and say in the handoff what real material would let you add it. Do not ship placeholder quotes like "Jane D., CEO", because placeholders get launched.

**No vague hero text.** The hero must say, in plain words: what this is, who it is for, and what to do next. Test: could a competitor paste this headline onto their site unchanged? If yes, rewrite it.
- Vague: "Unlock the future of work." / "Elevate your workflow."
- Specific: "Bookkeeping for Pune clinics, done by a named accountant each month."

**No AI slop copy.** Write like a person who knows the subject, using concrete nouns, real details and short sentences. Cut these on sight: unlock, elevate, seamless, supercharge, empower, revolutionise, game-changer, next-level, cutting-edge, state-of-the-art, leverage, delve, harness the power, unleash, reimagine, effortless, world-class, all-in-one, "the future of", "in today's fast-paced world", "your journey", "like never before". Also avoid the rule-of-three rhythm in every sentence and closing lines that restate the heading.

**No em dashes.** Not in copy, headings, alt text, meta descriptions or code comments that ship. Use a comma, colon, full stop or parentheses instead. Don't substitute a spaced hyphen or en dash to do the same job. This rule also applies to your own messages when writing for this owner.

## 4. Launch gate

A site is **not** ready to launch, and you must not describe it as launch-ready, until every item below is true:

1. **Custom domain connected.** No `*.vercel.app`, `*.netlify.app`, `*.lovable.app`, `*.github.io`, `*.webflow.io`, `*.framer.website` or similar as the public address, canonical URL or `og:url`. You usually can't connect DNS yourself, so ask the owner to confirm, and give them the steps for their host if they need them.
2. **Favicon added.** At minimum `<link rel="icon">` (SVG or 32px PNG) plus a 180px `apple-touch-icon`. Built from the real brand mark, not a default framework icon.
3. **"Made with …" tag removed.** No "Made with AI/Lovable/Bolt/Framer/Webflow/Wix", "Edit with Lovable", "Built with v0" or similar badges, scripts or footer lines. On builder platforms this often needs a plan setting as well as a code change; tell the owner if so.
4. **Privacy policy page** exists, is linked in the footer, and describes what this site actually collects (forms, analytics, cookies, payments, third parties).
5. **Terms and conditions page** exists and is linked in the footer.

For 4 and 5, draft the pages to match the site's real data practices and the owner's jurisdiction (for India, the Digital Personal Data Protection Act 2023 and IT Rules; for EU visitors, GDPR). Mark each draft clearly as needing review by a qualified lawyer before launch, since you are not one.

Also check before launch: page title and meta description written for the end user, Open Graph image, a real 404 page, working contact route, alt text on every meaningful image, keyboard navigation and visible focus, colour contrast at WCAG AA, and no console errors.

## 5. Checking your work ("make no mistakes")

The owner has asked for no mistakes. You can't promise perfection, but you can make sure nothing leaves your hands unchecked. Do all of this before every handoff:

1. **Run the checker** (section 7) on the site folder. Add `--launch` when anything is heading to production. Fix every BLOCKER. Look at every REVIEW line yourself and either fix it or explain why it is genuine (for example, a real, sourced customer count).
2. **Render and look at the page** at phone width (about 375px) and desktop width (about 1440px), using a browser or a headless screenshot. Check layout, overflow, contrast and that every link and button works.
3. **Reread every line of copy** against section 3 and the empathy map.
4. **Verify every fact, number, name, price and date** on the page against something the owner provided or a source you actually opened.
5. **Report honestly.** In the handoff, list what you verified, anything you could not verify, and every launch-gate item that is still open. Never say "done" or "ready" while a gate item or BLOCKER remains.

## 6. Research projects

When the skill is used for research (market research, competitor analysis, user research, literature reviews, or research that feeds a site):

- Start with the empathy map for the person who will use the research: what decision they are making and what they already know.
- Only cite sources you actually opened in this session. Never cite from memory, never invent a title, author, statistic or URL, and never cite a page for something it doesn't say.
- Attach each non-obvious claim to its source inline (a numbered marker such as [3] is fine).
- Flag anything that could be out of date, contested, or supported by only one source.
- **End every research output with a complete "References" section** listing every source used, numbered to match the inline markers, in this form:

  `[n] Author or organisation. "Title." Publisher or site, date published (or "n.d."). URL. Accessed DD Month YYYY.`

  Include sources that shaped your thinking even if not quoted, and note any source you could not access.

## 7. The checker script

Save this as `check_site.py` (for example in the scratch or working directory) and run:

```
python3 check_site.py <site_folder>            # design and content rules
python3 check_site.py <site_folder> --launch   # plus the launch gate
```

It scans HTML, CSS, JS/TS, JSX/TSX, Vue, Svelte, Astro, Markdown and JSON (skipping node_modules and build folders). Exit code 1 means at least one BLOCKER. It is a safety net, not a substitute for looking at the page: it cannot tell whether a quote is real or a photo is AI-made, which is why those show up as REVIEW items for you to judge.

```python
#!/usr/bin/env python3
"""Scan a website folder for "vibe-coded" patterns and launch blockers.

Usage: python check_site.py <site_folder> [--launch]

BLOCKER findings must be fixed. REVIEW findings need a human look, since a
script cannot tell a real testimonial from a fake one. With --launch, the
launch gate (favicon, legal pages, badges, domain) is also enforced.
Exit code is 1 when any BLOCKER is found.
"""
import colorsys
import re
import sys
from pathlib import Path

EXTS = {".html", ".htm", ".css", ".scss", ".js", ".jsx", ".ts", ".tsx",
        ".vue", ".svelte", ".astro", ".md", ".mdx", ".json"}
SKIP_DIRS = {"node_modules", ".git", "dist", "build", ".next", ".nuxt",
             ".svelte-kit", ".astro", "vendor", "coverage"}

findings = []


def add(level, path, line, rule, text):
    findings.append((level, str(path), line, rule, text.strip()[:140]))


# ---------- colour helpers ----------
NAMED_PURPLES = {"purple", "violet", "indigo", "fuchsia", "magenta", "orchid",
                 "plum", "mediumpurple", "blueviolet", "darkviolet",
                 "darkorchid", "mediumorchid", "rebeccapurple", "darkmagenta",
                 "slateblue", "mediumslateblue", "darkslateblue", "lavender"}


def hex_is_purple(h):
    h = h.lstrip("#")
    if len(h) in (3, 4):
        h = "".join(c * 2 for c in h[:3])
    if len(h) < 6:
        return False
    r, g, b = (int(h[i:i + 2], 16) / 255 for i in (0, 2, 4))
    return hsv_is_purple(r, g, b)


def hsv_is_purple(r, g, b):
    hue, sat, val = colorsys.rgb_to_hsv(r, g, b)
    return 0.68 <= hue <= 0.90 and sat >= 0.25 and val >= 0.2


def gradient_has_purple(body):
    low = body.lower()
    for word in re.findall(r"[a-z]+", low):
        if word in NAMED_PURPLES:
            return True
    for hx in re.findall(r"#([0-9a-f]{3,8})\b", low):
        if hex_is_purple(hx):
            return True
    for r, g, b in re.findall(r"rgba?\(\s*(\d+)[ ,]+(\d+)[ ,]+(\d+)", low):
        if hsv_is_purple(int(r) / 255, int(g) / 255, int(b) / 255):
            return True
    for hue in re.findall(r"hsla?\(\s*(\d+)", low):
        if 245 <= int(hue) <= 325:
            return True
    return False


# ---------- patterns ----------
EMOJI = re.compile("[\U0001F300-\U0001FAFF\U0001F000-\U0001F2FF"
                   "☀-➿⭐⭕⬛⬜️]")
EM_DASH = re.compile(r"—|&mdash;|&#8212;|&#x2014;|\\u2014| -- ")
TW_PURPLE_GRAD = re.compile(
    r"\b(?:from|via|to)-(?:purple|violet|indigo|fuchsia|pink)-\d{2,3}\b")
GRADIENT = re.compile(r"(?:linear|radial|conic)-gradient\(([^;{}]*)", re.I)
PILL_CSS = re.compile(r"border-radius\s*:\s*(\d+(?:\.\d+)?)(px|rem|em|%)", re.I)
TW_PILL = re.compile(r"\brounded-(?:full|\[9{3,}px\])\b")
CURSOR = re.compile(
    r"cursor\s*:\s*(?:none|url\()|custom-?cursor|cursor-?(?:follower|trail|dot|blob)"
    r"|magnetic|addEventListener\(\s*['\"](?:mousemove|pointermove)", re.I)
SCROLL_LIBS = re.compile(
    r"\bdata-aos\b|\baos\.(?:js|css|init)|ScrollTrigger|locomotive-scroll|"
    r"\blenis\b|scrollmagic|\bparallax\b|rellax|skrollr|scroll-?jack", re.I)
IN_VIEW = re.compile(r"whileInView|useInView|IntersectionObserver|animate-on-scroll", re.I)
FAKE_METRIC = re.compile(
    r"\b\d[\d,.]*\s*[kKmMbB]?\+?\s*(?:happy\s+|satisfied\s+|active\s+)?"
    r"(?:users|customers|clients|companies|teams|businesses|downloads|members|"
    r"creators|developers|installs|signups|reviews)\b"
    r"|\b(?:trusted|loved|used)\s+by\b|\b\d{2}(?:\.\d+)?%\s+(?:uptime|satisfaction|faster|"
    r"more|increase|growth)|\b[45]\.\d\s*(?:/\s*5|stars?|rating)|★|☆"
    r"|\bcountUp\b|\bcounter\b|odometer", re.I)
TESTIMONIAL = re.compile(r"testimonial|\breview(?:s|er)?\b|what (?:our|people) (?:customers|clients|users) say", re.I)
SLOP_WORDS = re.compile(
    r"\b(?:unlock(?:ing)? (?:the|your)|elevate|seamless(?:ly)?|revolutioni[sz]e|supercharge|"
    r"empower(?:ing|s)?|game[- ]?changer|next[- ]level|cutting[- ]edge|state[- ]of[- ]the[- ]art|"
    r"leverag(?:e|ing)|delve|harness(?:ing)? the power|unleash|in today'?s (?:fast[- ]paced|digital)|"
    r"transform (?:the way|your)|reimagin(?:e|ing)|effortless(?:ly)?|world[- ]class|"
    r"your (?:journey|one[- ]stop)|take (?:it|your \w+) to the next|built for the future|"
    r"the future of|like never before|all[- ]in[- ]one)\b", re.I)
MADE_WITH = re.compile(
    r"made (?:with|in|using)\s+(?:ai|lovable|bolt|framer|webflow|v0|wix|durable|"
    r"replit|10web|hostinger|base44|claude|chatgpt|gpt)|built with (?:ai|lovable|bolt|v0|"
    r"framer|webflow|base44)|edit with lovable|lovable-badge|bolt-badge|"
    r"powered by (?:ai|lovable|bolt|framer|webflow|wix|base44)|__framer-badge|"
    r"w-webflow-badge", re.I)
TEMP_DOMAIN = re.compile(
    r"[\w-]+\.(?:vercel\.app|netlify\.app|lovable\.app|lovable\.dev|bolt\.new|"
    r"github\.io|web\.app|firebaseapp\.com|pages\.dev|framer\.(?:website|app)|"
    r"webflow\.io|wixsite\.com|replit\.app|onrender\.com|herokuapp\.com|"
    r"base44\.app|glitch\.me|surge\.sh)\b", re.I)
AI_IMAGE = re.compile(
    r"(?:midjourney|dall-?e|stable-?diffusion|sdxl|firefly|ideogram|leonardo|"
    r"flux|generated|ai-?image|ai_img)[\w-]*\.(?:png|jpe?g|webp|avif)"
    r"|oaidalleapiprodscus|cdn\.midjourney", re.I)


def scan_file(path):
    try:
        text = path.read_text(encoding="utf-8", errors="ignore")
    except OSError:
        return
    lines = text.splitlines()
    is_code = path.suffix in {".js", ".jsx", ".ts", ".tsx", ".vue", ".svelte", ".astro"}

    for i, line in enumerate(lines, 1):
        if EMOJI.search(line):
            add("BLOCKER", path, i, "emoji", line)
        if EM_DASH.search(line):
            add("BLOCKER", path, i, "em-dash", line)
        if TW_PURPLE_GRAD.search(line):
            add("BLOCKER", path, i, "purple-gradient", line)
        for m in GRADIENT.finditer(line):
            if gradient_has_purple(m.group(1)):
                add("BLOCKER", path, i, "purple-gradient", line)
        if TW_PILL.search(line) and re.search(r"<(?:button|a|Button|Link)\b|btn|button|cta", line, re.I):
            add("BLOCKER", path, i, "pill-button", line)
        if CURSOR.search(line):
            add("BLOCKER", path, i, "cursor-effect", line)
        if MADE_WITH.search(line):
            add("BLOCKER", path, i, "made-with-badge", line)
        if AI_IMAGE.search(line):
            add("BLOCKER", path, i, "ai-image", line)
        if SCROLL_LIBS.search(line):
            add("REVIEW", path, i, "scroll-animation", line)
        if FAKE_METRIC.search(line):
            add("REVIEW", path, i, "metric-or-counter-needs-source", line)
        if TESTIMONIAL.search(line) and not is_code:
            add("REVIEW", path, i, "review-or-testimonial-needs-source", line)
        if SLOP_WORDS.search(line):
            add("REVIEW", path, i, "generic-copy", line)
        if TEMP_DOMAIN.search(line):
            add("REVIEW", path, i, "temporary-domain", line)

    # pill-shaped radius in CSS rules scoped to buttons / links / CTAs
    for block in re.finditer(r"([^{}]+)\{([^{}]*)\}", text):
        selector, body = block.group(1), block.group(2)
        if not re.search(r"btn|button|cta|\ba\b|link|\.pill", selector, re.I):
            continue
        for m in PILL_CSS.finditer(body):
            val, unit = float(m.group(1)), m.group(2).lower()
            px = val * 16 if unit in ("rem", "em") else val
            if (unit != "%" and px >= 24) or (unit == "%" and val >= 50):
                ln = text[:block.start(2) + m.start()].count("\n") + 1
                add("BLOCKER", path, ln, "pill-button", selector.strip() + " { " + m.group(0) + " }")

    # heavy use of in-view animations
    iv = len(IN_VIEW.findall(text))
    if iv > 4:
        add("REVIEW", path, 0, "scroll-animation", f"{iv} in-view animation hooks in one file")


def main():
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    launch = "--launch" in sys.argv
    if not args:
        print(__doc__)
        sys.exit(2)
    root = Path(args[0])
    files = [p for p in ([root] if root.is_file() else root.rglob("*"))
             if p.is_file() and p.suffix.lower() in EXTS
             and not any(part in SKIP_DIRS for part in p.parts)]
    for f in files:
        scan_file(f)

    all_text = "\n".join(f.read_text(encoding="utf-8", errors="ignore") for f in files)
    names = " ".join(str(f).lower() for f in (root.rglob("*") if root.is_dir() else [root]))

    has_motion = re.search(r"@keyframes|transition\s*:|animation\s*:|framer-motion|gsap", all_text)
    if has_motion and "prefers-reduced-motion" not in all_text:
        add("BLOCKER", root, 0, "reduced-motion",
            "Animations found but no prefers-reduced-motion handling")

    if launch:
        if not re.search(r"rel=[\"'](?:shortcut )?icon|favicon", all_text + names, re.I):
            add("BLOCKER", root, 0, "launch:favicon", "No favicon found")
        if "apple-touch-icon" not in all_text:
            add("REVIEW", root, 0, "launch:favicon", "No apple-touch-icon")
        if not re.search(r"privacy", names) and not re.search(r"href=[\"'][^\"']*privacy", all_text, re.I):
            add("BLOCKER", root, 0, "launch:privacy-page", "No privacy policy page or link")
        if not re.search(r"terms", names) and not re.search(r"href=[\"'][^\"']*terms", all_text, re.I):
            add("BLOCKER", root, 0, "launch:terms-page", "No terms and conditions page or link")
        add("REVIEW", root, 0, "launch:custom-domain",
            "Confirm with the owner that a custom domain is connected (a script cannot verify DNS)")

    order = {"BLOCKER": 0, "REVIEW": 1}
    findings.sort(key=lambda f: (order[f[0]], f[3], f[1], f[2]))
    seen = set()
    for lvl, p, ln, rule, txt in findings:
        key = (lvl, p, ln, rule)
        if key in seen:
            continue
        seen.add(key)
        loc = f"{p}:{ln}" if ln else p
        print(f"[{lvl}] {rule:<36} {loc}\n          {txt}")
    b = sum(1 for f in {(x[0], x[1], x[2], x[3]) for x in findings} if f[0] == "BLOCKER")
    r = sum(1 for f in {(x[0], x[1], x[2], x[3]) for x in findings} if f[0] == "REVIEW")
    print(f"\n{len(files)} files scanned: {b} blocker(s), {r} item(s) to review.")
    sys.exit(1 if b else 0)


if __name__ == "__main__":
    main()
```
