#!/usr/bin/env python3
"""Scan a website folder for "vibe-coded" patterns and launch blockers.

Usage: python check_site.py <site_folder> [--launch]

BLOCKER findings must be fixed. REVIEW findings need a human look, since a
script cannot tell a real testimonial from a fake one. With --launch, the
launch gate (favicon, legal pages, badges, domain) is also enforced.
Exit code is 1 when any BLOCKER is found.
"""
import colorsys
import re
import sys
from pathlib import Path

EXTS = {".html", ".htm", ".css", ".scss", ".js", ".jsx", ".ts", ".tsx",
        ".vue", ".svelte", ".astro", ".md", ".mdx", ".json"}
SKIP_DIRS = {"node_modules", ".git", "dist", "build", ".next", ".nuxt",
             ".svelte-kit", ".astro", "vendor", "coverage"}

findings = []


def add(level, path, line, rule, text):
    findings.append((level, str(path), line, rule, text.strip()[:140]))


# ---------- colour helpers ----------
NAMED_PURPLES = {"purple", "violet", "indigo", "fuchsia", "magenta", "orchid",
                 "plum", "mediumpurple", "blueviolet", "darkviolet",
                 "darkorchid", "mediumorchid", "rebeccapurple", "darkmagenta",
                 "slateblue", "mediumslateblue", "darkslateblue", "lavender"}


def hex_is_purple(h):
    h = h.lstrip("#")
    if len(h) in (3, 4):
        h = "".join(c * 2 for c in h[:3])
    if len(h) < 6:
        return False
    r, g, b = (int(h[i:i + 2], 16) / 255 for i in (0, 2, 4))
    return hsv_is_purple(r, g, b)


def hsv_is_purple(r, g, b):
    hue, sat, val = colorsys.rgb_to_hsv(r, g, b)
    return 0.68 <= hue <= 0.90 and sat >= 0.25 and val >= 0.2


def gradient_has_purple(body):
    low = body.lower()
    for word in re.findall(r"[a-z]+", low):
        if word in NAMED_PURPLES:
            return True
    for hx in re.findall(r"#([0-9a-f]{3,8})\b", low):
        if hex_is_purple(hx):
            return True
    for r, g, b in re.findall(r"rgba?\(\s*(\d+)[ ,]+(\d+)[ ,]+(\d+)", low):
        if hsv_is_purple(int(r) / 255, int(g) / 255, int(b) / 255):
            return True
    for hue in re.findall(r"hsla?\(\s*(\d+)", low):
        if 245 <= int(hue) <= 325:
            return True
    return False


# ---------- patterns ----------
EMOJI = re.compile("[\U0001F300-\U0001FAFF\U0001F000-\U0001F2FF"
                   "☀-➿⭐⭕⬛⬜️]")
EM_DASH = re.compile(r"—|&mdash;|&#8212;|&#x2014;|\\u2014| -- ")
TW_PURPLE_GRAD = re.compile(
    r"\b(?:from|via|to)-(?:purple|violet|indigo|fuchsia|pink)-\d{2,3}\b")
GRADIENT = re.compile(r"(?:linear|radial|conic)-gradient\(([^;{}]*)", re.I)
PILL_CSS = re.compile(r"border-radius\s*:\s*(\d+(?:\.\d+)?)(px|rem|em|%)", re.I)
TW_PILL = re.compile(r"\brounded-(?:full|\[9{3,}px\])\b")
CURSOR = re.compile(
    r"cursor\s*:\s*(?:none|url\()|custom-?cursor|cursor-?(?:follower|trail|dot|blob)"
    r"|magnetic|addEventListener\(\s*['\"](?:mousemove|pointermove)", re.I)
SCROLL_LIBS = re.compile(
    r"\bdata-aos\b|\baos\.(?:js|css|init)|ScrollTrigger|locomotive-scroll|"
    r"\blenis\b|scrollmagic|\bparallax\b|rellax|skrollr|scroll-?jack", re.I)
IN_VIEW = re.compile(r"whileInView|useInView|IntersectionObserver|animate-on-scroll", re.I)
FAKE_METRIC = re.compile(
    r"\b\d[\d,.]*\s*[kKmMbB]?\+?\s*(?:happy\s+|satisfied\s+|active\s+)?"
    r"(?:users|customers|clients|companies|teams|businesses|downloads|members|"
    r"creators|developers|installs|signups|reviews)\b"
    r"|\b(?:trusted|loved|used)\s+by\b|\b\d{2}(?:\.\d+)?%\s+(?:uptime|satisfaction|faster|"
    r"more|increase|growth)|\b[45]\.\d\s*(?:/\s*5|stars?|rating)|★|☆"
    r"|\bcountUp\b|\bcounter\b|odometer", re.I)
TESTIMONIAL = re.compile(r"testimonial|\breview(?:s|er)?\b|what (?:our|people) (?:customers|clients|users) say", re.I)
SLOP_WORDS = re.compile(
    r"\b(?:unlock(?:ing)? (?:the|your)|elevate|seamless(?:ly)?|revolutioni[sz]e|supercharge|"
    r"empower(?:ing|s)?|game[- ]?changer|next[- ]level|cutting[- ]edge|state[- ]of[- ]the[- ]art|"
    r"leverag(?:e|ing)|delve|harness(?:ing)? the power|unleash|in today'?s (?:fast[- ]paced|digital)|"
    r"transform (?:the way|your)|reimagin(?:e|ing)|effortless(?:ly)?|world[- ]class|"
    r"your (?:journey|one[- ]stop)|take (?:it|your \w+) to the next|built for the future|"
    r"the future of|like never before|all[- ]in[- ]one)\b", re.I)
MADE_WITH = re.compile(
    r"made (?:with|in|using)\s+(?:ai|lovable|bolt|framer|webflow|v0|wix|durable|"
    r"replit|10web|hostinger|base44|claude|chatgpt|gpt)|built with (?:ai|lovable|bolt|v0|"
    r"framer|webflow|base44)|edit with lovable|lovable-badge|bolt-badge|"
    r"powered by (?:ai|lovable|bolt|framer|webflow|wix|base44)|__framer-badge|"
    r"w-webflow-badge", re.I)
TEMP_DOMAIN = re.compile(
    r"[\w-]+\.(?:vercel\.app|netlify\.app|lovable\.app|lovable\.dev|bolt\.new|"
    r"github\.io|web\.app|firebaseapp\.com|pages\.dev|framer\.(?:website|app)|"
    r"webflow\.io|wixsite\.com|replit\.app|onrender\.com|herokuapp\.com|"
    r"base44\.app|glitch\.me|surge\.sh)\b", re.I)
AI_IMAGE = re.compile(
    r"(?:midjourney|dall-?e|stable-?diffusion|sdxl|firefly|ideogram|leonardo|"
    r"flux|generated|ai-?image|ai_img)[\w-]*\.(?:png|jpe?g|webp|avif)"
    r"|oaidalleapiprodscus|cdn\.midjourney", re.I)


def scan_file(path):
    try:
        text = path.read_text(encoding="utf-8", errors="ignore")
    except OSError:
        return
    lines = text.splitlines()
    is_code = path.suffix in {".js", ".jsx", ".ts", ".tsx", ".vue", ".svelte", ".astro"}

    for i, line in enumerate(lines, 1):
        if EMOJI.search(line):
            add("BLOCKER", path, i, "emoji", line)
        if EM_DASH.search(line):
            add("BLOCKER", path, i, "em-dash", line)
        if TW_PURPLE_GRAD.search(line):
            add("BLOCKER", path, i, "purple-gradient", line)
        for m in GRADIENT.finditer(line):
            if gradient_has_purple(m.group(1)):
                add("BLOCKER", path, i, "purple-gradient", line)
        if TW_PILL.search(line) and re.search(r"<(?:button|a|Button|Link)\b|btn|button|cta", line, re.I):
            add("BLOCKER", path, i, "pill-button", line)
        if CURSOR.search(line):
            add("BLOCKER", path, i, "cursor-effect", line)
        if MADE_WITH.search(line):
            add("BLOCKER", path, i, "made-with-badge", line)
        if AI_IMAGE.search(line):
            add("BLOCKER", path, i, "ai-image", line)
        if SCROLL_LIBS.search(line):
            add("REVIEW", path, i, "scroll-animation", line)
        if FAKE_METRIC.search(line):
            add("REVIEW", path, i, "metric-or-counter-needs-source", line)
        if TESTIMONIAL.search(line) and not is_code:
            add("REVIEW", path, i, "review-or-testimonial-needs-source", line)
        if SLOP_WORDS.search(line):
            add("REVIEW", path, i, "generic-copy", line)
        if TEMP_DOMAIN.search(line):
            add("REVIEW", path, i, "temporary-domain", line)

    # pill-shaped radius in CSS rules scoped to buttons / links / CTAs
    for block in re.finditer(r"([^{}]+)\{([^{}]*)\}", text):
        selector, body = block.group(1), block.group(2)
        if not re.search(r"btn|button|cta|\ba\b|link|\.pill", selector, re.I):
            continue
        for m in PILL_CSS.finditer(body):
            val, unit = float(m.group(1)), m.group(2).lower()
            px = val * 16 if unit in ("rem", "em") else val
            if (unit != "%" and px >= 24) or (unit == "%" and val >= 50):
                ln = text[:block.start(2) + m.start()].count("\n") + 1
                add("BLOCKER", path, ln, "pill-button", selector.strip() + " { " + m.group(0) + " }")

    # heavy use of in-view animations
    iv = len(IN_VIEW.findall(text))
    if iv > 4:
        add("REVIEW", path, 0, "scroll-animation", f"{iv} in-view animation hooks in one file")


def main():
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    launch = "--launch" in sys.argv
    if not args:
        print(__doc__)
        sys.exit(2)
    root = Path(args[0])
    files = [p for p in ([root] if root.is_file() else root.rglob("*"))
             if p.is_file() and p.suffix.lower() in EXTS
             and not any(part in SKIP_DIRS for part in p.parts)]
    for f in files:
        scan_file(f)

    all_text = "\n".join(f.read_text(encoding="utf-8", errors="ignore") for f in files)
    names = " ".join(str(f).lower() for f in (root.rglob("*") if root.is_dir() else [root]))

    has_motion = re.search(r"@keyframes|transition\s*:|animation\s*:|framer-motion|gsap", all_text)
    if has_motion and "prefers-reduced-motion" not in all_text:
        add("BLOCKER", root, 0, "reduced-motion",
            "Animations found but no prefers-reduced-motion handling")

    if launch:
        if not re.search(r"rel=[\"'](?:shortcut )?icon|favicon", all_text + names, re.I):
            add("BLOCKER", root, 0, "launch:favicon", "No favicon found")
        if "apple-touch-icon" not in all_text:
            add("REVIEW", root, 0, "launch:favicon", "No apple-touch-icon")
        if not re.search(r"privacy", names) and not re.search(r"href=[\"'][^\"']*privacy", all_text, re.I):
            add("BLOCKER", root, 0, "launch:privacy-page", "No privacy policy page or link")
        if not re.search(r"terms", names) and not re.search(r"href=[\"'][^\"']*terms", all_text, re.I):
            add("BLOCKER", root, 0, "launch:terms-page", "No terms and conditions page or link")
        add("REVIEW", root, 0, "launch:custom-domain",
            "Confirm with the owner that a custom domain is connected (a script cannot verify DNS)")

    order = {"BLOCKER": 0, "REVIEW": 1}
    findings.sort(key=lambda f: (order[f[0]], f[3], f[1], f[2]))
    seen = set()
    for lvl, p, ln, rule, txt in findings:
        key = (lvl, p, ln, rule)
        if key in seen:
            continue
        seen.add(key)
        loc = f"{p}:{ln}" if ln else p
        print(f"[{lvl}] {rule:<36} {loc}\n          {txt}")
    b = sum(1 for f in {(x[0], x[1], x[2], x[3]) for x in findings} if f[0] == "BLOCKER")
    r = sum(1 for f in {(x[0], x[1], x[2], x[3]) for x in findings} if f[0] == "REVIEW")
    print(f"\n{len(files)} files scanned: {b} blocker(s), {r} item(s) to review.")
    sys.exit(1 if b else 0)


if __name__ == "__main__":
    main()
